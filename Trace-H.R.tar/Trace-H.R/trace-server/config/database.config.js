module.exports = {
    url: 'mongodb://localhost:27017/kairos-hr',
    secret: 'ogA9ppB$S!dy!hu3Rauvg!L96'
}
